CREATE TRIGGER guardar_exempleado
AFTER DELETE ON PERSONAL
BEGIN
    INSERT INTO ExEmpleados (NSS, Nombre_Personal, Apellido_Paterno, Apellido_Materno, Puesto, Dia_Ingreso, Mes_Ingreso, Ano_Ingreso)
    VALUES (OLD.NSS, OLD.Nombre_Personal, OLD.Apellido_Paterno, OLD.Apellido_Materno, OLD.Puesto, OLD.Dia_Ingreso, OLD.Mes_Ingreso, OLD.Ano_Ingreso);
END;

